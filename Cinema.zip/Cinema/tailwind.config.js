/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.html',
  './src/**/*.vue',
  './src/**/*.jsx',
  './src/**/*.js',
  './index.html',
  './App.vue',
  './main.js',
  './src/**/*.ts',
  './src/**/*.tsx',],
  theme: {
    extend: {},
  },
  plugins: [],
}

